Word Drama GitHub Pages 直接部署包
解压后，将 index.html、images 文件夹、image_manifest.json、vocabulary_5223.csv、vocabulary_5223.json 上传到仓库根目录（不要只上传 ZIP）。
注意：GitHub 网页端不能直接上传一个文件夹时，可以多选文件，或使用 GitHub Desktop / git push。
重要：必须替换仓库根目录原有的 index.html，而不是新增 index 12.html。
本版基于 WordDrama_v14，保留5223词游戏及原有后备图片。
现有77张独立图片文件，其中63个词条与独立图片建立映射；其余词条继续使用游戏内置的后备图。
